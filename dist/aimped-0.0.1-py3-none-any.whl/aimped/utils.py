__version__ = '0.0.1'

def get_aimped_version():
    return f'aimped version: {__version__}'


if __name__ == '__main__':
    print(get_aimped_version())