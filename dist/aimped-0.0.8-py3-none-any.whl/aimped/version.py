# Author: AIMPED
# Date: 2023-March-11
# Description: Contains the version of aimped library.


__version__ = "0.0.8"
