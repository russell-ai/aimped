# Author: AIMPED
# Date: 2023-March-11
# Copyright: AIMPED
# Description: Version file for AIMPED


__version__ = "0.1.51"
